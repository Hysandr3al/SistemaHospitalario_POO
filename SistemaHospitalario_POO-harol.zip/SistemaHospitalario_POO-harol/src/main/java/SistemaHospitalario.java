import java.util.Scanner;
import java.util.List;

// --- IMPORTS DE LOS DAOs Y CLASES ---
import dao.DoctorDAO;
import dao.PacienteDAO;
import dao.MedicamentoDAO;
import Sujetos.Doctor;
import Sujetos.Paciente;
import Farmacia.Medicamento;

// --- IMPORTS DE LOS MENÚS ---
import recursoslogistica.MenuLogistica;
import pacienteepisodio.Menu;
import Farmacia.MenuFarmacia;
import TalentoHumano.MenuTalentoHumano;

public class SistemaHospitalario {

    public static void main(String[] args) {
        inicializarTodo(); // Carga automática de datos

        Scanner scanner = new Scanner(System.in);
        int opcion = -1;
        String[] dummyArgs = {}; 

        do {
            System.out.println("\n=================================================");
            System.out.println("      SISTEMA HOSPITALARIO INTEGRADO (POO)");
            System.out.println("=================================================");
            System.out.println(" 1. Modulo de Pacientes y Episodios (Admision)");
            System.out.println(" 2. Modulo de Recursos y Logistica ");
            System.out.println(" 3. Modulo de Farmacia");
            System.out.println(" 4. Modulo de Talento Humano");
            System.out.println(" 5. Gestion de Staff Medico (Doctores)"); // <--- COMBINADO
            System.out.println(" 0. Salir del Sistema");
            System.out.println("=================================================");
            System.out.print(" Seleccione el modulo a gestionar: ");

            try {
                String entrada = scanner.nextLine();
                opcion = Integer.parseInt(entrada);

                switch (opcion) {
                    case 1:
                        System.out.println("\n>>> Entrando a ADMISION...");
                        pacienteepisodio.Menu.main(dummyArgs); 
                        break;
                    case 2:
                        System.out.println("\n>>> Entrando a LOGISTICA...");
                        recursoslogistica.MenuLogistica.main(dummyArgs);
                        break;
                    case 3:
                        System.out.println("\n>>> Entrando a FARMACIA...");
                        Farmacia.MenuFarmacia.main(dummyArgs);
                        break;
                    case 4:
                         System.out.println("\n>>> Entrando a RRHH...");
                         TalentoHumano.MenuTalentoHumano.main(dummyArgs);
                         break;
                    case 5:
                         menuDoctores(); 
                         break;
                    case 0:
                        System.out.println("\nCerrando sistema completo. ¡Hasta luego!");
                        break;
                    default:
                        System.out.println("(!) Opcion no valida.");
                }
            } catch (Exception e) {
                System.out.println("(!) Error: " + e.getMessage());
            }
        } while (opcion != 0);
        scanner.close(); 
    }

    
    private static void menuDoctores() {
        Scanner sc = new Scanner(System.in);
        int op = -1;
        
        do {
            System.out.println("\n--- GESTION DE STAFF MEDICO ---");
            System.out.println("1. Ver lista de Doctores");
            System.out.println("2. Registrar Nuevo Doctor");
            System.out.println("0. Volver al menu principal");
            System.out.print("Seleccione: ");
            
            try {
                op = Integer.parseInt(sc.nextLine());
                switch (op) {
                    case 1 -> listarDoctores();
                    case 2 -> registrarDoctorManual();
                    case 0 -> System.out.println("Volviendo...");
                    default -> System.out.println("Opcion no valida.");
                }
            } catch (Exception e) {
                System.out.println("Error de entrada.");
            }
        } while (op != 0);
       
    }

    
    private static void listarDoctores() {
        System.out.println("\n--- LISTA DE DOCTORES ---");
        DoctorDAO docDAO = new DoctorDAO();
        List<Doctor> lista = docDAO.listar();

        if (lista.isEmpty()) {
            System.out.println("[!] No hay doctores registrados.");
        } else {
            for (Doctor d : lista) {
                System.out.println("- Dr/a. " + d.getNombres() + " " + d.getApellidos() + 
                                   " | Esp: " + d.getEspecialidad() + " | Turno: " + d.getHorario());
            }
        }
        esperarEnter();
    }

    private static void registrarDoctorManual() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n--- CONTRATAR NUEVO DOCTOR ---");
        
        System.out.print("Nombre: "); String nom = sc.nextLine();
        System.out.print("Apellido: "); String ape = sc.nextLine();
        System.out.print("DNI: "); String dni = sc.nextLine();
        System.out.print("Telefono: "); String tel = sc.nextLine();
        System.out.print("Sexo (M/F): "); String sex = sc.nextLine();
        
        System.out.print("Edad: "); 
        int edad = Integer.parseInt(sc.nextLine());
        
        System.out.print("Especialidad: "); String esp = sc.nextLine();
        System.out.print("Horario: "); String hor = sc.nextLine();
        System.out.print("Salario: "); 
        double sal = Double.parseDouble(sc.nextLine());

        Doctor d = new Doctor(nom, ape, tel, dni, sex, edad, esp, hor, sal);
        DoctorDAO dao = new DoctorDAO();
        
        if (dao.registrar(d)) {
            System.out.println(" Doctor registrado en BD.");
        } else {
            System.out.println(" Error al registrar.");
        }
        esperarEnter();
    }

    private static void esperarEnter() {
        System.out.println("\nPresione Enter para continuar...");
        try { System.in.read(); } catch(Exception e){}
    }

    
    private static void inicializarTodo() {
        System.out.println("Verificando datos del sistema completo...");
        
        DoctorDAO docDAO = new DoctorDAO();
        if (docDAO.listar().isEmpty()) {
            System.out.println(" -> Insertando Doctores por defecto...");
            docDAO.registrar(new Doctor("Juan", "Perez", "099123", "1001", "M", 45, "Cardiologia", "Mañana", 2500.0));
            docDAO.registrar(new Doctor("Maria", "Gomez", "099654", "1002", "F", 38, "Pediatria", "Tarde", 2300.0));
        }

        PacienteDAO pacDAO = new PacienteDAO();
        if (pacDAO.listar().isEmpty()) {
            System.out.println(" -> Insertando Pacientes por defecto...");
            pacDAO.registrar(new Paciente("Ana", "Lopez", "098111", "1701", "F", 25, "O+", "Ninguna", 0, "Norte"));
            pacDAO.registrar(new Paciente("Luis", "Diaz", "098333", "1702", "M", 60, "A-", "Polvo", 0, "Sur"));
        }

        MedicamentoDAO medDAO = new MedicamentoDAO();
        if (medDAO.listar().isEmpty()) {
            System.out.println(" -> Insertando Farmacia por defecto...");
            medDAO.registrar(new Medicamento(0, "Paracetamol", "Analgesico", 5.0, 100, "2026-12-01", 0.0));
            medDAO.registrar(new Medicamento(0, "Ibuprofeno", "Antiinflamatorio", 8.0, 50, "2025-08-15", 0.10));
        }
        System.out.println("¡Sistema listo!\n");
    }
}
