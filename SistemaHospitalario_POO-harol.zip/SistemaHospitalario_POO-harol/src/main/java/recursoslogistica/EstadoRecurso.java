package recursoslogistica;

public enum EstadoRecurso {
    DISPONIBLE,
    EN_USO,
    AGOTADO
}