package recursoslogistica;

public enum CategoriaInsumo {
    MEDICAMENTO,
    MATERIAL_QUIRURGICO,
    DESECHABLE,
    OXIGENO
}
