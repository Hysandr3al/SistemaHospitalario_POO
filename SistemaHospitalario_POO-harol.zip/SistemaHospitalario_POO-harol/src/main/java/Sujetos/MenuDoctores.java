package Sujetos;

import java.util.Scanner;
import java.util.List;
import dao.DoctorDAO;

public class MenuDoctores {

    private static final Scanner sc = new Scanner(System.in);
    private static final DoctorDAO doctorDAO = new DoctorDAO();

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n=== GESTION DE STAFF MEDICO (DOCTORES) ===");
            System.out.println("1. Ver lista de Doctores (SQL)");
            System.out.println("2. Registrar Nuevo Doctor");
            System.out.println("3. Actualizar Datos");
            System.out.println("4. Eliminar Doctor");
            System.out.println("0. Volver al menu principal");
            System.out.print("Seleccione: ");
            
            try { opcion = Integer.parseInt(sc.nextLine()); } catch (Exception e) { opcion = -1; }

            switch (opcion) {
                case 1 -> listarDoctores();
                case 2 -> registrarDoctor();
                case 3 -> actualizarDoctor();
                case 4 -> eliminarDoctor();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("[!] Opcion no valida.");
            }
        } while (opcion != 0);
    }

    private static void listarDoctores() {
        System.out.println("\n--- LISTA DE DOCTORES ---");
        List<Doctor> lista = doctorDAO.listar();

        if (lista.isEmpty()) {
            System.out.println("[!] No hay doctores registrados.");
        } else {
            System.out.println("ID | NOMBRE                  | ESPECIALIDAD   | HORARIO");
            System.out.println("-------------------------------------------------------");
            for (Doctor d : lista) {
                System.out.printf("%-2d | %-23s | %-14s | %s%n", 
                    d.getIdDoctor(), 
                    d.getApellidos() + " " + d.getNombres(), 
                    d.getEspecialidad(), 
                    d.getHorario());
            }
        }
        esperarEnter();
    }

    private static void registrarDoctor() {
        System.out.println("\n--- CONTRATAR DOCTOR ---");
        System.out.print("Nombre: "); String nom = sc.nextLine();
        System.out.print("Apellido: "); String ape = sc.nextLine();
        System.out.print("DNI: "); String dni = sc.nextLine();
        System.out.print("Telefono: "); String tel = sc.nextLine();
        System.out.print("Sexo (M/F): "); String sex = sc.nextLine();
        System.out.print("Edad: "); int edad = leerEntero();
        System.out.print("Especialidad: "); String esp = sc.nextLine();
        System.out.print("Horario: "); String hor = sc.nextLine();
        System.out.print("Salario: "); double sal = leerDouble();

        Doctor d = new Doctor(nom, ape, tel, dni, sex, edad, esp, hor, sal);
        
        if (doctorDAO.registrar(d)) System.out.println("[OK] Registrado.");
        else System.out.println("[ERROR] No se pudo registrar.");
        esperarEnter();
    }

    private static void actualizarDoctor() {
        System.out.println("\n--- ACTUALIZAR ---");
        System.out.print("ID del doctor: "); int id = leerEntero();
        Doctor d = doctorDAO.buscarPorId(id);

        if (d != null) {
            System.out.println("Editando a: " + d.getApellidos());
            System.out.print("Nuevo Horario (Enter para saltar): ");
            String hor = sc.nextLine();
            if (!hor.isEmpty()) d.setHorario(hor);

            if (doctorDAO.modificar(d)) System.out.println("[OK] Actualizado.");
            else System.out.println("[ERROR] Fallo BD.");
        } else {
            System.out.println("[!] No encontrado.");
        }
        esperarEnter();
    }

    private static void eliminarDoctor() {
        System.out.print("ID a eliminar: "); int id = leerEntero();
        if (doctorDAO.eliminar(id)) System.out.println("[OK] Eliminado.");
        else System.out.println("[ERROR] Fallo.");
        esperarEnter();
    }

    // Utilidades
    private static int leerEntero() { try { return Integer.parseInt(sc.nextLine()); } catch (Exception e) { return 0; } }
    private static double leerDouble() { try { return Double.parseDouble(sc.nextLine()); } catch (Exception e) { return 0.0; } }
    private static void esperarEnter() { System.out.println("\nEnter para seguir..."); sc.nextLine(); }
}