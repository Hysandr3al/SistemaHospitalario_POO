package Sujetos;

import java.util.Date;

public class Empleado extends Persona {
    private String idEmpleado;
    private String puesto;
    private Date fechaIngreso;
    private double salario;

    public Empleado(String idEmpleado, String nombres, String apellidos, 
                   String telefono, String dni, String sexo, int edad,
                   String puesto, Date fechaIngreso, double salario) {
        super(nombres, apellidos, telefono, dni, sexo, edad);
        this.idEmpleado = idEmpleado;
        this.puesto = puesto;
        this.fechaIngreso = fechaIngreso;
        this.salario = salario;
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Empleado: " + nombres + " " + apellidos + " - Puesto: " + puesto);
    }
    
    // Getters necesarios
    public String getIdEmpleado() { return idEmpleado; }
}