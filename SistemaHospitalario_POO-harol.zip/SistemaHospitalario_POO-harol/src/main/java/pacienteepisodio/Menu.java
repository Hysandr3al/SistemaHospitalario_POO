package pacienteepisodio;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import Sujetos.Paciente;
import dao.PacienteDAO; 

public class Menu {

    private static final Scanner sc = new Scanner(System.in);
    private static Paciente paciente; 
    private static final PacienteDAO pacienteDAO = new PacienteDAO(); 
    
    private static final Map<Integer, Runnable> acciones = new HashMap<>();

    public static void main(String[] args) {
        cargarAcciones();
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opcion: ");
            acciones.getOrDefault(opcion, () -> System.out.println("Opcion no valida")).run();
        } while (opcion != 0);
    }

    private static void cargarAcciones() {
        acciones.put(1, Menu::registrarPaciente);
        acciones.put(2, Menu::mostrarPaciente);
        acciones.put(3, Menu::agregarEpisodio);
        acciones.put(4, Menu::mostrarHistoriaClinica);
        acciones.put(0, () -> System.out.println("Saliendo del modulo..."));
    }

    private static void mostrarMenu() {
        System.out.println("\n=== MODULO PACIENTE Y EPISODIO ===");
        System.out.println("1. Registrar paciente nuevo");
        System.out.println("2. Buscar/Ver paciente");
        System.out.println("3. Agregar episodio (Historia Clinica)");
        System.out.println("4. Ver historia clinica completa");
        System.out.println("0. Volver al menu principal");
    }

    
    private static void registrarPaciente() {
        System.out.println("\n--- Registro de Paciente ---");
        String nombres   = leerTexto("Nombres: ");
        String apellidos = leerTexto("Apellidos: ");
        String telefono  = leerTexto("Telefono: ");
        String dni       = leerTexto("DNI: ");
        String sexo      = leerTexto("Sexo: ");
        int edad         = leerEntero("Edad: ");
        String gs        = leerTexto("Grupo sanguineo: ");
        String alergias  = leerTexto("Alergias: ");
        String direccion = leerTexto("Direccion: "); 

        paciente = new Paciente(nombres, apellidos, telefono, dni, sexo, edad, gs, alergias, 0, direccion);
        
        if(pacienteDAO.registrar(paciente)) {
            System.out.println("[OK] Paciente guardado en Base de Datos y seleccionado.");
        } else {
            System.out.println("[ERROR] No se pudo guardar (Tal vez el DNI ya existe).");
        }
        esperarEnter();
    }

    
    private static void mostrarPaciente() {
        
        if (paciente != null) {
            System.out.println("\n--- PACIENTE SELECCIONADO ---");
            paciente.mostrarInfo();
            System.out.println("Direccion: " + paciente.getDireccion());
            
        
        } else {
            
            System.out.println("\n[!] No hay ningun paciente seleccionado.");
            System.out.print("Desea buscar uno por DNI en la Base de Datos? (S/N): ");
            String resp = sc.nextLine();
            
            if (resp.equalsIgnoreCase("S")) {
                buscarEnBD(); 
            }
        }
        esperarEnter();
    }

    private static void buscarEnBD() {
        String dniBusq = leerTexto("Ingrese el DNI a buscar: ");
        
        List<Paciente> lista = pacienteDAO.listar();
        boolean encontrado = false;

        for (Paciente p : lista) {
            if (p.getDni().equals(dniBusq)) {
                paciente = p; 
                paciente.setHistoriaClinica(new HistoriaClinica(paciente));
                
                System.out.println("[OK] Paciente encontrado.");
                paciente.mostrarInfo();
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("[!] No se encontro ese DNI.");
        }
    }

    
    private static void agregarEpisodio() {
        if (paciente == null) {
            System.out.println("[!] Primero debe seleccionar un paciente (Opcion 1 o 2).");
            esperarEnter();
            return;
        }

        System.out.println("\n--- AGREGAR EPISODIO ---");
        System.out.println("Paciente: " + paciente.getNombres() + " " + paciente.getApellidos());
        System.out.println("1. Cita Ambulatoria | 2. Hospitalizacion | 3. Cirugia | 4. Urgencia");
        
        int tipo = leerEntero("Seleccione: ");
        String desc = leerTexto("Descripcion: ");

        switch (tipo) {
            case 1 -> paciente.getHistoriaClinica().agregarEpisodio(new CitaAmbulatoria(desc));
            case 2 -> {
                int cama = leerEntero("Cama: ");
                paciente.getHistoriaClinica().agregarEpisodio(new Hospitalizacion(desc, cama));
            }
            case 3 -> {
                String tipoC = leerTexto("Tipo Cirugia: ");
                paciente.getHistoriaClinica().agregarEpisodio(new Cirugia(desc, tipoC));
            }
            case 4 -> {
                String triage = leerTexto("Nivel Triage: ");
                paciente.getHistoriaClinica().agregarEpisodio(new Urgencia(desc, triage));
            }
            default -> System.out.println("Opcion invalida.");
        }
        System.out.println("[OK] Episodio agregado.");
        esperarEnter();
    }

    
    private static void mostrarHistoriaClinica() {
        if (paciente == null) { System.out.println("No hay paciente seleccionado."); return; }
        
        System.out.println(paciente.getHistoriaClinica());
        for (Episodio e : paciente.getHistoriaClinica().getEpisodios()) {
            System.out.println(" - " + e);
        }
        esperarEnter();
    }

    
    private static String leerTexto(String m) { System.out.print(m); return sc.nextLine(); }
    
    private static int leerEntero(String m) {
        System.out.print(m);
        while (!sc.hasNextInt()) { sc.next(); }
        int v = sc.nextInt(); sc.nextLine(); return v;
    }

    private static void esperarEnter() {
        System.out.println("\nPresione ENTER para continuar...");
        try { System.in.read(); } catch(Exception e){}
    }
}