package TalentoHumano;

import java.util.Scanner;
import java.util.Date;
import java.util.Map;
import Sujetos.Empleado; 

public class MenuTalentoHumano {

    private static final Scanner sc = new Scanner(System.in);
    // Creamos el gestor de personal (Memoria RAM)
    private static final Personal gestionPersonal = new Personal(); 

    public static void main(String[] args) {
        
        if (gestionPersonal.getEmpleados().isEmpty()) {
            System.out.println("(Cargando personal de prueba en memoria...)");
            gestionPersonal.altaEmpleadoBasico("ENF001", "Harol", "Tola", "Enfermero", new Date(), 1500.0);
            gestionPersonal.altaEmpleadoBasico("ADM002", "Jorge", "Ramirez", "Admision", new Date(), 1200.0);
            gestionPersonal.altaEmpleadoBasico("TEC003", "Pedro", "Castillo", "Laboratorio", new Date(), 1350.0);
            gestionPersonal.altaEmpleadoBasico("LIM004", "Maria", "Lopez", "Limpieza", new Date(), 950.0);
        }

        int opcion;
        do {
            System.out.println("\n========================================");
            System.out.println("      MODULO DE TALENTO HUMANO (RRHH)   ");
            System.out.println("========================================");
            System.out.println(" 1. Ver Lista de Personal Activo");
            System.out.println(" 2. Contratar Nuevo Empleado");
            System.out.println(" 0. Volver al menu principal");
            System.out.println("========================================");
            System.out.print(" Seleccione: ");
            
            try { 
                opcion = Integer.parseInt(sc.nextLine()); 
            } catch(Exception e) { 
                opcion = -1; 
            }

            switch (opcion) {
                case 1 -> listarPersonal();
                case 2 -> contratarEmpleado();
                case 0 -> System.out.println("Saliendo de RRHH...");
                default -> System.out.println("(!) Opcion no valida");
            }
        } while (opcion != 0);
        
    }

    private static void listarPersonal() {
        System.out.println("\n--- PLANILLA DE PERSONAL ---");
        System.out.println("ID      | NOMBRE COMPLETO       | PUESTO");
        System.out.println("------------------------------------------------");
        
        
        for (Empleado e : gestionPersonal.getEmpleados().values()) {
            // Formato bonito tipo tabla
            System.out.printf("%-7s | %-20s | %s%n", 
                e.getIdEmpleado(), 
                e.getNombres() + " " + e.getApellidos(), 
                "Empleado" 
            );
            
        }
        System.out.println("------------------------------------------------");
        esperarEnter();
    }

    private static void contratarEmpleado() {
        System.out.println("\n--- CONTRATACION ---");
        System.out.print("ID (ej. ENF99): "); String id = sc.nextLine();
        System.out.print("Nombre: "); String nom = sc.nextLine();
        System.out.print("Apellido: "); String ape = sc.nextLine();
        System.out.print("Puesto: "); String puesto = sc.nextLine();
        
        
        gestionPersonal.altaEmpleadoBasico(id, nom, ape, puesto, new Date(), 1500.0);
        System.out.println("✅ Empleado contratado (Guardado en RAM).");
        esperarEnter();
    }

    private static void esperarEnter() {
        System.out.println("\nPresione ENTER para volver...");
        try { System.in.read(); } catch(Exception e){}
    }
}